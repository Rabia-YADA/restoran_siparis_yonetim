
<?php include 'fonksiyonlar/fonksiyon.php';

$masaDetay = new sistem();
@$masaid= $_GET["masaid"];

	

?>


<!doctype html>
<html lang="tr">
  <head>
   
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

    <link rel="stylesheet" type="text/css" href="dosyalar/style.css">

    
    <script type="text/javascript">
      
    $(document).ready(function() {

      $(document).on("click","#btnn",function() {
    var masaId= $(".input").val();
        
        $.post("islemler.php?islem=hesap", {"MASAID": masaId}, function(post_veri) {

          window.location.href = 'masadetay.php?masaid='+masaId;

        })
});

      

      var id= "<?php echo $masaid; ?>";

      $("#veri").load("islemler.php?islem=goster&id="+id);
      
        $('#btn').click(function(){

          $.ajax({ //sayfayı yenilemeden butona basmamla eklenen ürünü ekrana basar.
              
              type : "POST",
              url : 'islemler.php?islem=ekle',
              data : $('#formum').serialize(),
              success: function(donen_veri){
              $("#veri").load("islemler.php?islem=goster&id="+id);
              $('#formum').trigger("reset");//seçili radio butonları temizler
              $('#cevap').html(donen_veri);
              },

          })

      });

        $('#urunler a').click(function(){

          var sectionId = $(this).attr('sectionId');
          console.log(sectionId);

          $('#sonuc').load("islemler.php?islem=urun&katid="+sectionId).fadeIn();
        })

    });
    </script>
 
    <title>Cafe Sipariş Sistemi</title>


  </head>
  <body>
  	
  	<div class="container-fluid">

    <?php 
      //echo $masaid;
      if($masaid!= null) :
      $result= $masaDetay->masaGetir($db, $masaid);
      $dizi= $result->fetch_assoc();  

      @$deger= $_GET["deger"]; 
      echo $deger;

      switch ($deger) {
        case '1':
          $masaDetay->masaGetir($db, $dizi["ID"]);
          break;
      }
            

    ?>

        <div class="row border border-dark" id="mdDiv1" >
          
              <div class="col-md-3" id="mdDiv2">

                    <div class="row">

                          <div class="col-md-12 border-bottom border-success bg-success text-white text-center mx-auto p-4 text-center" id="mdDiv3"><a href="index.php" class="btn btn-warning">Ana Sayfa</a><br/><?php echo $dizi["MAD"]; ?></div>
                          
                          <!-- buraya anlık siparişler -->
                          <div class="col-md-12" id="veri"></div>
                          <div id="cevap"></div>
                          <!-- buraya anlık siparişler -->

                    </div>
              </div>


              <div class="col-md-7" style="background-color: #f9f9f9" >

                <div class="row"><form id="formum">
                    <div class="col-md-12" id="sonuc" style="min-height: 600px;">
                      <img src="./dosyalar/katSec.png">
                    </div>
                </div>
                <div class="row">

                    <div class="col-md-12" id="mdDiv4">
                        <div class="row">
                            <div class="col-md-6">
                                <input type="hidden" name="masaid" value="<?php echo $dizi["ID"]; ?>">
                                <input type="button" id="btn" value="ekle" class="btn btn-success btn-block mt-4">
                            </div>
                            <div class="col-md-6">
                                <?php 
                                    for( $i=1; $i<=11; $i++){ 
                                      echo '<label class="btn btn-success m-2">
                                            <input type="radio" name="adet" value="'.$i.'"/>'.$i.'
                                            </label>';
                                    }
                                ?>
                                
                            </div>

                        </div>
                    </div>
                </div>

              </div>

              <!-- KATEGORİLER -->
              <div class="col-md-2" id="urunler">
                    <?php $masaDetay->urunKategori($db); ?>
                  
              </div>
               <!-- KATEGORİLER -->
        </div>

        <?php 

          else :
            echo "hata";
          endif;
        ?>

       

      
    </div>


    
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
  </body>
</html>