
<?php include 'fonksiyonlar/fonksiyon.php';

@$masaid= $_GET["masaid"];

?>

<!doctype html>
<html lang="tr">
  <head>
   
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
 	<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

	<link rel="stylesheet" type="text/css" href="dosyalar/style.css">

	<title>Cafe Sipariş Sistemi</title>

    <script type="text/javascript">
      
    $(document).ready(function() { 


      	


    	
    	$("#yakala a").click(function() {
    		
    		var sectionId= $(this).attr('sectionId');//tıklanan linkin özelliğini al
    		
    		$.post("islemler.php?islem=sil", {"URUNID": sectionId}, function(post_veri) {

    			window.location.reload();//işlem gerçekleştiğinde sayfayı otomatik refresh eder

    		})

    	})

    })
    </script>


  </head>
  <body>
  	

<?php

function bildirim($mesaj, $renk) {

	echo '<div class="alert alert-'.$renk.' mt-4 text-center">'.$mesaj.'</div>';

}
@$islem= $_GET["islem"];

switch ($islem) :

	case 'hesap':
		if (!$_POST) {
			
			echo "sadece posttan gelen işlemlere izin var";//güvenlik önlemi

		}
		else {
			
			
			@$masaid= htmlspecialchars($_POST["MASAID"]);
			echo "string";
			$anlikSiparisCek= $db-> query("SELECT * FROM anlikSiparis WHERE MASAID=$masaid");
			while ($re= mysqli_fetch_assoc($anlikSiparisCek)) {
				$as= mysqli_num_rows($re);
				echo $as;
				$a= $re["MASAID"];
				$b= $re["URUNID"];
				$c= $re["UAD"];
				$d= $re["UFIYAT"];
				$e= $re["ADET"];
				$bugun=date("Y-m-d");

				$anlikRaporCek= $db-> query("SELECT ADET FROM rapor WHERE MASAID=$masaid and URUNID = $b");
				$raporAdet = 0;

				while($reRapor = mysqli_fetch_assoc($anlikRaporCek)) {
					$raporAdet = $reRapor['ADET'];
				}

				$e += $raporAdet;
				$urunRaporSil= $db-> query("DELETE FROM rapor WHERE MASAID=$masaid and URUNID = $b");

				$raporEkle= $db-> query("INSERT INTO rapor (MASAID,URUNID,UAD,UFIYAT,ADET,TARIH)VALUES ($a,$b,'$c',$d,$e,'$bugun')");
				
				
				
			}
var_dump($raporEkle);
			
			$hesapAl= $db-> query("DELETE FROM anlikSiparis WHERE MASAID=$masaid");

		}

		break;

	case 'sil':
		
		if (!$_POST) {
			
			echo "sadece posttan gelen işlemlere izin var";//güvenlik önlemi

		}
		else {
			
			@$gelenId= htmlspecialchars($_POST["URUNID"]);

			$silIslem= $db-> query("DELETE FROM anlikSiparis WHERE URUNID=$gelenId");

		}

	break;

	case 'goster':

	$id= htmlspecialchars($_GET["id"]);

		$siparisBilgisi= $db -> query("SELECT * FROM anlikSiparis WHERE MASAID= $id ");

		if(mysqli_num_rows($siparisBilgisi)==0) {
			bildirim("Henüz siparişiniz yok.", "danger");
		}

			

		else {

			echo '<table class="table table-bordered table-striped text-center">
				<thead>
				<tr class="bg-dark text-white ">
				<th scope="col">Ürün Adı</th>
				<th scope="col">Adet</th>
				<th scope="col">Tutar</th>
				<th scope="col">İşlem</th>
				</tr>
				</thead>
				<tbody>
			';
				
			$adet= 0;
			$toplamTutar= 0;

			while($arraySBilgisi= mysqli_fetch_assoc($siparisBilgisi)):

				$tutar= $arraySBilgisi["UFIYAT"]*$arraySBilgisi["ADET"];

				$adet+= $arraySBilgisi["ADET"];
				$toplamTutar+= $tutar;//toplam tutar ve toplam adet işlemleri
				$masaid= $arraySBilgisi["MASAID"];
				

				echo '<tr>
					<td class="mx-auto text-center p-3">'.$arraySBilgisi["UAD"].'</td>
					<td class="mx-auto text-center p-3">'.$arraySBilgisi["ADET"].'</td>
					<td class="mx-auto text-center p-3">'.$tutar.'</td>
					<td id="yakala"><a class="btn btn-danger mt-2 text-white" sectionId="'.$arraySBilgisi["URUNID"].'">SİL</></td>
				</tr>';

			endwhile;


				echo '
				<tr class="bg-dark text-white text-center">
					<td class="font-weight-bold">TOPLAM</td>
					<td class="font-weight-bold">'.$adet.'</td>
					<td colspan="2" class="font-weight-bold text-warning">'.$toplamTutar.' TL</td>
				</tr>
				</tbody></table>

				<div class="row">
					<div class="col-md-12">
						<form id="hesapForm">
							<input type="hidden" class="input" name="masaid" value="'.$masaid.'">
						 	<input type="button" id="btnn" value="HESABI AL" class="btn btn-danger btn-block mt-4" ">
						</form>
					</div>

				</div>

				';

		}

		break;

	case 'ekle':

	if ($_POST) :
		
		@$masaid= htmlspecialchars($_POST['masaid']);
		@$urunid= htmlspecialchars($_POST['urunid']);
		@$adet= htmlspecialchars($_POST['adet']); 
		

		if ($masaid== "" || $urunid== "" || $adet=="") {

			bildirim("Boş alan bırakmayınız.", "danger");
			
		}
		else{
			//aynı üründen bir daha eklenirse adet güncelleme işlemleri
			$kontrolSiparis= $db-> query("select * from anliksiparis where URUNID=$urunid and MASAID=$masaid");
			
			if ($num_rows = mysqli_num_rows($kontrolSiparis)!= 0) {
				
				$urunDizi=mysqli_fetch_assoc($kontrolSiparis);
				$guncelAdet= $adet+ $urunDizi["ADET"];
				$islemId= $urunDizi["URUNID"];

				$guncelle= $db-> query("UPDATE anlikSiparis set ADET= $guncelAdet WHERE URUNID= $islemId");
				
				bildirim("Adet güncellendi", "success");

			}
			else {

				$secilenUrun= $db-> query("SELECT * FROM urunler WHERE ID=$urunid");
				$row= mysqli_fetch_assoc($secilenUrun);

				$urunad= $row["UAD"];
				$urunFiyat= $row["FIYAT"];


				$ekle= $db -> query("INSERT INTO anlikSiparis (MASAID, URUNID, UAD, UFIYAT, ADET) VALUES ($masaid, $urunid,'$urunad', $urunFiyat, $adet) ");

					bildirim("Eklendi", "success");

			}


		}

		
	else :
		echo '<div class="alert alert-danger mt-4 text-center">
						Hata var
					</div>';

	endif;
		
		break;

	case 'urun':
		$katid= htmlspecialchars($_GET["katid"]);
		$u= $db-> query("SELECT * FROM urunler WHERE KID= $katid");
		while($row= mysqli_fetch_assoc($u)):
			echo '<label class="btn btn-dark m-2">
                  <input type="radio" name="urunid" value="'.$row["ID"].'"/>'.$row["UAD"].'
                  </label>';
		endwhile;

		break;

endswitch;


?>
      

    
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
</body>
</html>


