<?php 
ob_start();
include_once("fonksiyons/fonksiyonAdmin.php"); 
$Yonetim = new yonetim();
$Yonetim->cookieKontrol($db, false);

?>


<!doctype html>
<html lang="tr">
<head>
   
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
 
    <title>Cafe Sipariş Kontrol</title>

    <style>
        body{
            height: 100%;
            width: 100%;
            position: absolute;
        }
        .container-fluid,
        .row-fluid{
            height: inherit;
        }
        #lk:link, #lk:visited {
            color:#888;
            text-decoration:none;
        }
        #lk:hover{
            color:#000;
        }
        #div2{
            min-height: 100%; background-color: #EEE;

        }
        #div1{
            background-color: #fff;
            border: 1px solid #F1F1F1;
            border-radius: 5px;
        }
    </style>

</head>
<body>
  <div class="container-fluid bg-light">
    <div class="row row-fluid">
        <div class="col-md-2 border-right bg-info">
            <div class="row">
            <div class="col md-12 bg-light p-4 mx-auto text-center font-weight-bold">
                <h3><?php echo $Yonetim->getKulAdi($db) ?></h3>
            </div>
            </div>
            <div class="row">
                <div class="col-md-12 bg-light p-2 pl-3 border-bottom border-top text-white">
                    <a href="kontrol.php?islem=masayonetim"id="lk">Masa Yönetimi</a>
                </div>
                <div class="col-md-12 bg-light p-2 pl-3 border-bottom border-top text-white">
                    <a href="kontrol.php?islem=urunyonetim"id="lk">Ürün Yönetimi</a>
                </div>
                <div class="col-md-12 bg-light p-2 pl-3 border-bottom border-top text-white">
                    <a href="kontrol.php?islem=katyonetim"id="lk">Kategori Yönetimi</a>
                </div>
                <div class="col-md-12 bg-light p-2 pl-3 border-bottom border-top text-white">
                    <a href="kontrol.php?islem=raporyonetim"id="lk">Rapor Yönetimi</a>
                </div>
                <div class="col-md-12 bg-light p-2 pl-3 border-bottom border-top text-white">
                    <a href="kontrol.php?islem=sifdegistirme"id="lk">Şifre Değiştir</a>
                </div>
                <div class="col-md-12 bg-light p-2 pl-3 border-bottom border-top text-white">
                    <a href="kontrol.php?islem=cikis"id="lk">Çıkış</a>
                </div>

                <table class="table text-center table-light table-bordered mt-2 table-striped">
                    <thead>
                    <tr class="table-warning">
                        <th scope="col" colspan="4">ANLIK DURUM</th>
                    </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th scope="col" colspan="3">Toplam Sipariş</th>
                            <th scope="col" colspan="1"class="text-danger"><?php $Yonetim->toplamSiparis($db); ?></th>
                        </tr>
                        <tr>
                            <th scope="col" colspan="3">Doluluk Oranı</th>
                            <th scope="col" colspan="1"class="text-danger"><?php $Yonetim->dolulukOran($db) ?></th>
                        </tr>
                        <tr>
                            <th scope="col" colspan="3">Toplam Masa</th>
                            <th scope="col" colspan="1"class="text-danger"><?php $Yonetim->toplamMasa($db); ?></th>
                        </tr>
                        <tr>
                            <th scope="col" colspan="3">Toplam Kategori</th>
                            <th scope="col" colspan="1"class="text-danger"><?php $Yonetim->toplamKategori($db); ?></th>
                        </tr>
                        <tr>
                            <th scope="col" colspan="3">Toplam Ürün</th>
                            <th scope="col" colspan="1"class="text-danger"><?php $Yonetim->toplamUrun($db); ?></th>
                        </tr>

                    </tbody>
                </table>

            </div>
        </div>
<div class="col-md-10">
    <div class="row bg-light" id="div2">
        <div class="col-md-12 mt-4" id="div1">
            


            <?php
            @$islem=$_GET["islem"];
            switch ($islem):
            ///////////  Masa Yönetimi   /////////
                case "masayonetim":
                    $Yonetim->masaYonetim($db);
                break;

                case "masasil":
                    $Yonetim->masaSil($db);
                break;

                case "masaguncel":
                    $Yonetim->masaGuncelle($db);
                break;

                case "masaekle":
                    $Yonetim->masaEkle($db);
                break;
                
                ///////////  Urun Yönetimi   /////////
                case "urunyonetim":
                    $Yonetim->urunYonetim($db,0);
                break;

                case "urunsil":
                    $Yonetim->urunSil($db);
                break;

                case "urunguncel":
                    $Yonetim->urunGuncel($db);
                break;

                case "urunekle":
                    $Yonetim->urunEkle($db);
                break;

                case "katgore":
                    $Yonetim->urunYonetim($db,2);
                    break;

                case "aramasonuc":
                    $Yonetim->urunYonetim($db,1);
                break;
                ///////////  Kategori Yönetimi   /////////
                case "katyonetim":
                    $Yonetim->kategoriYonetim($db);
                break;

                case "katekle":
                    $Yonetim->kategoriEkle($db);
                break;

                case "katsil":
                    $Yonetim->kategoriSil($db);
                break;

                case "katguncel":
                    $Yonetim->kategoriGuncel($db);
                break;



                case "raporyonetim":
                    $Yonetim->rapor($db);
                break;

                case "sifdegistirme":
                    $Yonetim->sifreDegistir($db);
                break;

                case "cikis":
                    $Yonetim->cikis($Yonetim->getKulAdi($db));
                break;


            endswitch;
            ?>
        </div>
    </div>
</div>

</div>
</div>
  
  	


    
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
</body>
</html>
<? ob_flush(); ?>