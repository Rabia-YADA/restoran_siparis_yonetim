<?php ob_start();
include_once("fonksiyons/fonksiyonAdmin.php"); 
      $Yonetim = new yonetim();
      $Yonetim->cookieKontrol($db, true);

?>

<!doctype html>
<html lang="tr">
  <head>
   
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">

    <link rel="stylesheet" href="../admin/styleAdm.css">
 
    <title>Giriş</title>


  </head>
  <body>
    
    <div class="container text-center">
    <div class="row mx-auto">

    <div class="col col-md-4"></div>


    <div class="col col-md-4 mx-auto text-center" id="login">

    <?php
        @$buton=$_POST["buton"];
        if(!$buton):
        ?>
        <form action="<?php $_SERVER['PHP_SELF'] ?>" method="post">
        <div class="col col-md-12 border-bottom p-2"><h3>Yönetici Giriş</h3></div>
        <div class="col col-md-12"><input type="text" name="kulad" class="form-control mt-2"required="required" placeholder="Yönetici Adınız" autofocus="autofocus"/></div>
        <div class="col col-md-12"><input type="password" name="sifre" class="form-control mt-2"required="required" placeholder="Şifreniz"/></div>
        <div class="col col-md-12"><input type="submit" name="buton" class="btn btn-success mt-2" value="GİRİŞ"/></div>
        </form>

        <?php

        else:
            @$sifre=htmlspecialchars($_POST["sifre"]);
            @$kulad=htmlspecialchars($_POST["kulad"]);
            
            if($sifre=="" || $kulad==""):
                echo "Bilgiler Boş Olamaz";
                header("refresh:2,url=index.php");
            else:
                $Yonetim->girisKontrol($db, $kulad, $sifre);
                //$clas->giriskont($vt,$kulad,$sifre);

            endif;
        endif;

        ?>

    </div>
    <div class="col col-md-4"></div>
</div>
</div>


    
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
  </body>
</html>
<? ob_flush(); ?>