<?php

$servername = "localhost";
$database = "siparis";
$username = "root";
$password = "root";
// Create connection
$db = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$db) {
    die("Bağlantı Hatası: " . 
mysqli_connect_error());
}
$db->set_charset("utf8");

class yonetim {

	//kullanıcı adı çekme
	public function getKulAdi($mysqli) {

		$qKulad= $mysqli-> query("SELECT * FROM yonetim");
		$rKulad= mysqli_fetch_assoc($qKulad);

		return $rKulad["KADI"];
	}

	//Çıkış işlemi
	function cikis($deger){
       $deger=md5(sha1(md5($deger)));
       setcookie("admin","$deger",time()-10);
       $this->uyari("success","Çıkış Yapılıyor","index.php");
   	}

	//istatistik islemleri
	function toplamSiparis($mysqli){

		$qUrunAdet= $mysqli-> query("SELECT SUM(ADET) FROM anliksiparis");
		$rUrunAdet= mysqli_fetch_assoc($qUrunAdet);
		echo $rUrunAdet['SUM(ADET)'];

   	}

	public function dolulukOran($mysqli) {

		$qDoluBilgisi= $mysqli-> query("SELECT * FROM doluluk");
		$arrayDoluluk= mysqli_fetch_assoc($qDoluBilgisi);

		$toplamMasa= $arrayDoluluk["BOS"] + $arrayDoluluk["DOLU"];
		$oran= ($arrayDoluluk["DOLU"]/$toplamMasa)*100; 
		echo $oran= substr($oran, 0, 4). "%";
	}

    function toplamMasa($mysqli){
    	$qToplamMasa= $mysqli-> query("SELECT * FROM masalar");
        echo mysqli_num_rows($qToplamMasa);
    }

    function toplamKategori($mysqli){

    	$qToplamKat= $mysqli-> query("SELECT * FROM kategori");
    	echo mysqli_num_rows($qToplamKat);

    }

    function toplamUrun($mysqli){

    	$qtoplamUrun= $mysqli-> query("SELECT * FROM urunler");
    	echo mysqli_num_rows($qtoplamUrun);

    }

	private function uyari($tip, $metin, $sayfa) {
		echo '<div class="alert alert-'.$tip.'">'.$metin.'</div>';
		header('Refresh:2; url='.$sayfa.'');
	}

	//masa yönetimi işlemleri
	function masaYonetim($mysqli){
		$qMasalar= $mysqli-> query("SELECT * FROM masalar");
        echo '<table class="table text-center table-striped table-bordered mx-auto col-md-6 mt-4">
                <thead>
                    <tr>
                        <th scope="col"><a href="kontrol.php?islem=masaekle"class="btn btn-success">+</a> Masa Adı</th>
                        <th scope="col">Güncelle</th>
                        <th scope="col">Sil</th>
                    </tr>
                </thead>
                <tbody>';
        while ($rmasalar=mysqli_fetch_assoc($qMasalar)):
        echo '
                    <tr>
                        <td>'.$rmasalar["MAD"].'</td>
                        <td><a href="kontrol.php?islem=masaguncel&masaid='.$rmasalar["ID"].'"class="btn btn-warning">Güncelle</a></td>
                        <td><a href="kontrol.php?islem=masasil&masaid='.$rmasalar["ID"].'"class="btn btn-danger">Sil</a></td>
                                                 
                        </td>
                    </tr>
                ';
        endwhile;
        echo '</tbody>

            </table>';
    }

    function masaSil($mysqli){

        $masaid=$_GET["masaid"];
        if($masaid!=""&& is_numeric($masaid)){

        	$qmasalar= $mysqli-> query("DELETE FROM masalar WHERE ID= $masaid");
            $this->uyari("success","Masa Başarıyla Silindi","kontrol.php?islem=masayonetim");
        }
            
        else{
            $this->uyari("danger","Hata Oluştu","kontrol.php?islem=masayonetim");
        }

    }

    function masaGuncelle($mysqli){

        @$buton=$_POST["buton"];
        echo '<div class="col-md-3 text-center mx-auto mt-5 table-bordered">';
        if($buton){
        	@$masaad=htmlspecialchars($_POST["masaad"]);
            @$masaid=htmlspecialchars($_POST["masaid"]);
            if($masaad=="" || $masaid=="") {
                $this->uyari("danger","Bilgiler Boş Olamaz","kontrol.php?islem=masayonetim");
            }
            else{
				$qMasalar= $mysqli-> query("UPDATE masalar SET MAD='$masaad' WHERE ID=$masaid");
                $this->uyari("success","MASA GÜNCELLENDİ","kontrol.php?islem=masayonetim");
            }
        }
            

        else{
        	$masaid=$_GET["masaid"];
            $qMasaBil=$mysqli-> query("SELECT * FROM masalar WHERE ID=$masaid");
            $rMasaBil= mysqli_fetch_assoc($qMasaBil);
            echo '
                <form action="" method="post">
                    <div class="col-md-12 table-light border-bottom"><h4>MASA GÜNCELLE</h4></div>
                    <div class="col-md-12 table-light"><input type="text" name="masaad" class="form-control mt-3" value="'.$rMasaBil["MAD"].'"/></div>
                    <div class="col-md-12 table-light"><input name="buton" type="submit" class="btn btn-success mt-3 mb-3"/></div>
                    <input type="hidden" name="masaid" value="'.$rMasaBil["ID"].'"/>
                </form>
                ';
        }
            echo '</div>';

    }

    function masaEkle($mysqli){

        @$buton=$_POST["buton"];
        echo '<div class="col-md-3 text-center mx-auto mt-5 table-bordered">';
        if($buton){
        	 @$masaad=htmlspecialchars($_POST["masaad"]);
            if($masaad=="") {
                $this->uyari("danger","Bilgiler Boş Olamaz","kontrol.php?islem=masayonetim");
            }
            else{
            	$qEkle= $mysqli-> query("INSERT INTO masalar (MAD) VALUES ('$masaad')");
            	$this->uyari("success","MASA EKLENDİ","kontrol.php?islem=masayonetim");
            }

        } 
        else{
            echo '
                <form action="" method="post">
                    <div class="col-md-12 table-light border-bottom"><h4>MASA EKLE</h4></div>
                    <div class="col-md-12 table-light"><input type="text" name="masaad" class="form-control mt-3" require/></div>
                    <div class="col-md-12 table-light"><input name="buton" type="submit" class="btn btn-success mt-3 mb-3"/></div>
                </form>
                ';
        }
        echo '</div>';

    }

    //ÜRÜN YÖNETİM İŞLEMLERİ
    function urunYonetim($mysqli,$tercih){

        if ($tercih==1) {
        	/// Arama Kodları
            $aramabuton=$_POST["aramabuton"];
            $urun=$_POST["urun"];
            if($aramabuton){
            	$qUrunBil= $mysqli-> query("SELECT * FROM urunler WHERE UAD LIKE '%$urun%' ");
            }
        }

        elseif ($tercih==2) {
        	$arama=$_POST["arama"];
            $katid=$_POST["katid"];
            if($arama){
            	$qUrunBil= $mysqli-> query("SELECT * FROM urunler WHERE KID= $katid");
            }
        }

        // Kategoriye Göre Listeleme
        elseif ($tercih==0) {
            $qUrunBil= $mysqli-> query("SELECT * FROM urunler");
        }


        echo '<table class="table text-center table-striped table-bordered mx-auto col-md-6 mt-4 table-dark">
                <thead>
                <tr>
                    <th>
                    <form action="kontrol.php?islem=aramasonuc" method="post">
                    <input type="search" name="urun" class="form-control"/></th>
                    <th><input type="submit" name="aramabuton" value="ARA" class="btn btn-danger"/></form></th>
                    <th>
                    <form action="kontrol.php?islem=katgore" method="post">
                    <select name="katid" class="form-control">
                    <option value="0">Kategoriler</option>';
                        
                        $qKateg= $mysqli-> query("SELECT * FROM kategori");
                        while ($katson= mysqli_fetch_assoc($qKateg)) {
                        	echo '
                            <option value="'.$katson["ID"].'">'.$katson["KAD"].'</option>';
                        }
                            
        echo '</select></th>
                    <th><input type="submit" name="arama" value="GETİR" class="btn btn-danger"/></form></th>
                </tr>
                </thead>
                </table>';

        echo '<table class="table text-center table-striped table-bordered mx-auto col-md-6 mt-4">
                <thead>
                    <tr>
                        <th scope="col"><a href="kontrol.php?islem=urunekle"class="btn btn-success">+</a> Ürün Adı</th>
                        <th scope="col">Fiyat</th>
                        <th scope="col">Güncelle</th>
                        <th scope="col">Sil</th>
                    </tr>
                </thead>
                <tbody>';
        while ($sonuc=mysqli_fetch_assoc($qUrunBil))
        {
            echo '
                    <tr>
                        <td>'.$sonuc["UAD"].'</td>
                        <td>'.$sonuc["FIYAT"].'</td>
                        <td><a href="kontrol.php?islem=urunguncel&urunid='.$sonuc["ID"].'"class="btn btn-warning">Güncelle</a></td>
                        <td><a href="kontrol.php?islem=urunsil&urunid='.$sonuc["ID"].'"class="btn btn-danger">Sil</a></td>
                                                 
                        </td>
                    </tr>
                ';
        }
        echo '</tbody>

            </table>';
    }

//ÜRÜN SİLME İŞLEMLERİ
    function urunsil($mysqli){

        @$urunid=$_GET["urunid"];
        if($urunid!=""&& is_numeric($urunid)) {
            $qAnlikSip= $mysqli-> query("SELECT * FROM anliksiparis WHERE URUNID= $urunid");
            if($qAnlikSip->num_rows!=0) {
                echo '<div class="alert alert-info mt-5">
                Bu Ürün Aşağıdaki Masalarda Mevcut;<br>';
                while ($rMasabilgi=mysqli_fetch_assoc($qAnlikSip)){
                    $masaid=$rMasabilgi["MASAID"];
                    $qMasa= $mysqli-> query("SELECT * FROM masalar WHERE ID= $masaid");
                    $rMasa= mysqli_fetch_assoc($qMasa);

                    echo "-".$masasonuc["ad"]."<br>";
                }
                echo '</div>';
            }

            else {
                $qUrunler= $mysqli-> query("DELETE FROM urunler WHERE ID= $urunid");
                @$this->uyari("success","Ürün Başarıyla Silindi","kontrol.php?islem=urunyonetim");
            }
        }
        else {
            $this->uyari("danger","Hata Oluştu","kontrol.php?islem=urunyonetim");
        }

        
    }

//ÜRÜN GÜNCELLEME İŞLEMLERİ
    function urunGuncel($mysqli){

        @$buton=$_POST["buton"];
        echo '<div class="col-md-3 text-center mx-auto mt-5 table-bordered">';
        if($buton) {

            @$urunad=htmlspecialchars($_POST["urunad"]);
            @$urunid=htmlspecialchars($_POST["urunid"]);
            @$fiyat=htmlspecialchars($_POST["fiyat"]);
            @$katid=htmlspecialchars($_POST["katid"]);

            if($urunad=="" || $urunid=="" || $katid=="" || $fiyat=="") {
                $this->uyari("danger","Bilgiler Boş Olamaz","kontrol.php?islem=urunyonetim");
            }
            else{
                $qUrunler= $mysqli-> query(" UPDATE urunler SET UAD= '$urunad', FIYAT=$fiyat, KID=$katid where ID=$urunid ");
                
                if ($qUrunler) {
                        $this->uyari("success","ÜRÜN GÜNCELLENDİ","kontrol.php?islem=urunyonetim");

                }

            }
        }    

        else {

            $urunid=$_GET["urunid"];
            $aktar=$mysqli ->query("SELECT * FROM urunler WHERE ID=$urunid");
            $rAktar= mysqli_fetch_assoc($aktar);
            ?>
                <form action="<?php $_SERVER['PHP_SELF'];?>" method="post">
            <?php
                    echo '<div class="col-md-12 table-light border-bottom"><h4>ÜRÜN GÜNCELLE</h4></div>
                    <div class="col-md-12 table-light">Ürün Adı<input type="text" name="urunad" class="form-control mt-3" value="'.$rAktar["UAD"].'"/></div>
                    <div class="col-md-12 table-light">Ürün Fiyatı<input type="text" name="fiyat" class="form-control mt-3" value="'.$rAktar["FIYAT"].'"/></div>
                    <div class="col-md-12 table-light">';
                        
                        $katid=$rAktar["KID"];
                        $katcek=$mysqli-> query("SELECT * FROM kategori");
                        
                        echo'Kategori <select name="katid"class="mt-3">';
                        
                        while ($katson= mysqli_fetch_assoc($katcek)) {
                            if($katson["ID"]==$katid){
                                echo '<option value="'.$katson["ID"].'" selected="selected">'.$katson["KAD"].'</option>';
                            }
                            else{
                                echo '<option value="'.$katson["ID"].'">'.$katson["KAD"].'</option>';
                            }
                        }
                        echo '</select>';

                    echo '</div>
                    <div class="col-md-12 table-light"><input name="buton" value="Güncelle" type="submit" class="btn btn-success mt-3 mb-3"/></div>
                    <input type="hidden" name="urunid" value="'.$urunid.'"/>
                </form>
                ';
        }
            
        echo '</div>';

    }

//ÜRÜN EKLEME İŞLEMLERİ
    function urunEkle($mysqli){

            @$buton=$_POST["buton"];
            echo '<div class="col-md-3 text-center mx-auto mt-5 table-bordered">';
            if($buton) {
                @$urunad=htmlspecialchars($_POST["urunad"]);
                @$fiyat=htmlspecialchars($_POST["fiyat"]);
                @$katid=htmlspecialchars($_POST["katid"]);

                if($urunad=="" || $katid=="" || $fiyat=="") {
                    $this->uyari("danger","Bilgiler Boş Olamaz","kontrol.php?islem=urunyonetim");
                }
                else {
                    $qUruns= $mysqli-> query("INSERT INTO urunler (KID, UAD, FIYAT) VALUES ($katid,'$urunad',$fiyat)");
                    $this->uyari("success","ÜRÜN EKLENDİ","kontrol.php?islem=urunyonetim");
                }
            }    
            else {

            ?>
                    <form action="<?php $_SERVER['PHP_SELF'];?>" method="post">
                        <?php
                        echo '<div class="col-md-12 table-light border-bottom"><h4>ÜRÜN EKLEME</h4></div>
                    <div class="col-md-12 table-light">Ürün Adı<input type="text" name="urunad" class="form-control mt-3"/></div>
                    <div class="col-md-12 table-light">Ürün Fiyatı<input type="text" name="fiyat" class="form-control mt-3"/></div>
                    <div class="col-md-12 table-light">';

                        $qKatBil= $mysqli-> query("SELECT * FROM kategori");
                        echo'Kategori <select name="katid"class="mt-3">';
                    
                        while ($rKatBil= mysqli_fetch_assoc($qKatBil)) {

                            echo '<option value="'.$rKatBil["ID"].'">'.$rKatBil["KAD"].'</option>';
                        }
                        echo '</select>';

                        echo '</div>
                    <div class="col-md-12 table-light"><input name="buton" value="EKLE" type="submit" class="btn btn-success mt-3 mb-3"/></div>
                </form>
                ';
                }
                    echo '</div>';

    }

//KATEGORİ YÖNETİM İŞLEMLERİ
    function kategoriYonetim($mysqli){
                $qKateg=$mysqli-> query("SELECT * FROM kategori");
                echo '<table class="table text-center table-striped table-bordered mx-auto col-md-6 mt-4">
                
                <thead>
                    <tr>
                        <th scope="col"><a href="kontrol.php?islem=katekle"class="btn btn-success">+</a> Kategori Adı</th>
                        <th scope="col">Güncelle</th>
                        <th scope="col">Sil</th>
                    </tr>
                </thead>
                
                <tbody>';
                            while ($sonuc=mysqli_fetch_assoc($qKateg)):
                                echo '
                    <tr>
                        <td>'.$sonuc["KAD"].'</td>
                        <td><a href="kontrol.php?islem=katguncel&katid='.$sonuc["ID"].'"class="btn btn-warning">Güncelle</a></td>
                        <td><a href="kontrol.php?islem=katsil&katid='.$sonuc["ID"].'"class="btn btn-danger">Sil</a></td>
                                                 
                        </td>
                    </tr>
                ';
                            endwhile;
                            echo '</tbody>

            </table>';

    }


    function kategoriSil($mysqli){

                @$katid=$_GET["katid"];
                
                if($katid!=" " && is_numeric($katid)) {
                    $qKateg= $mysqli-> query("DELETE FROM kategori WHERE ID=$katid");
                    @$this->uyari("success","Kategori Başarıyla Silindi","kontrol.php?islem=katyonetim");
                }
                    
                else {
                    @$this->uyari("danger","Hata Oluştu","kontrol.php?islem=katyonetim");
                }
    }


    function kategoriEkle($mysqli){

                            @$buton=$_POST["buton"];
                            echo '<div class="col-md-3 text-center mx-auto mt-5 table-bordered">';
                            
                            if($buton) {

                                 @$katad=htmlspecialchars($_POST["katad"]);
                                
                                if($katad=="") {
                                    $this->uyari("danger","Bilgiler Boş Olamaz","kontrol.php?islem=katyonetim");
                                }

                                else{
                                    $qKateg= $mysqli-> query("INSERT INTO kategori (KAD) VALUES ('$katad')");
                                    $this->uyari("success","KATEGORİ EKLENDİ","kontrol.php?islem=katyonetim");;
                                }
                            }
                               
                                   

                            else {
                                echo '
                            
                                <form action="" method="post">
                                    <div class="col-md-12 table-light border-bottom"><h4>KATEGORİ EKLE</h4></div>
                                    <div class="col-md-12 table-light"><input type="text" name="katad" class="form-control mt-3" require/></div>
                                    <div class="col-md-12 table-light"><input name="buton" type="submit" class="btn btn-success mt-3 mb-3"/></div>
                                </form>
                                ';
                            }
                            echo '</div>';

                        }


    function kategoriGuncel($mysqli){

                        @$buton=$_POST["buton"];
                        echo '<div class="col-md-3 text-center mx-auto mt-5 table-bordered">';
                        
                        if($buton) {

                            @$katad=htmlspecialchars($_POST["katad"]);
                            @$katid=htmlspecialchars($_POST["katid"]);

                            if($katad=="" || $katid=="") {
                                $this->uyari("danger","Bilgiler Boş Olamaz","kontrol.php?islem=katyonetim");
                            }

                            else {
                                $qKateg= $mysqli-> query("UPDATE kategori SET KAD='$katad' WHERE ID=$katid");
                                $this->uyari("success","KATEGORİ GÜNCELLENDİ","kontrol.php?islem=katyonetim");
                            }
                               
                        }
                           

                        else {

                            $katid=$_GET["katid"];
                            $qKateg= $mysqli-> query("SELECT * FROM kategori WHERE ID=$katid");
                            $sonuc= mysqli_fetch_assoc($qKateg);
                            ?>
                            <form action="<?php $_SERVER['PHP_SELF'];?>" method="post">
                                <?php
                                        echo '<div class="col-md-12 table-light border-bottom"><h4>KATEGORİ GÜNCELLE</h4></div>
                                <div class="col-md-12 table-light">Kategori Adı<input type="text" name="katad" class="form-control mt-3" value="'.$sonuc["KAD"].'"/></div>
                                <div class="col-md-12 table-light"><input name="buton" value="Güncelle" type="submit" class="btn btn-success mt-3 mb-3"/></div>
                                <input type="hidden" name="katid" value="'.$katid.'"/>
                            </form>
                    ';
                    }
                            echo '</div>';

    }

// ŞİFRE DEĞİŞTİRME İŞLEMLERİ
    function sifreDegistir($mysqli) {

                                @$buton=$_POST["buton"];
                                echo '<div class="col-md-3 text-center mx-auto mt-5 table-bordered">';
                                if($buton) {

                                    @$eskisif=htmlspecialchars($_POST["eskisif"]);
                                    @$yen1=htmlspecialchars($_POST["yen1"]);
                                    @$yen2=htmlspecialchars($_POST["yen2"]);

                                    if($eskisif=="" || $yen1=="" ||$yen2=="") {
                                        
                                        $this->uyari("danger","Bilgiler Boş Olamaz","kontrol.php?islem=sifdegistirme");
                                    }

                                    else {
                                        
                                        $eskisifson=md5(sha1(md5($eskisif)));
                                        $qYonetim= $mysqli-> query("SELECT * FROM yonetim WHERE SIFRE= '$eskisifson' ");
                                        
                                        if(mysqli_num_rows($qYonetim)==0) {
                                            
                                            $this->uyari("danger","Eski Şifre Hatalı","kontrol.php?islem=sifdegistirme");
                                        }
                                        elseif ($yen1!=$yen2) {
                                           
                                            $this->uyari("danger","Yeni Şifreler Uyumsuz","kontrol.php?islem=sifdegistirme");
                                        }
                                        else {
                                            
                                            $yenisifre=md5(sha1(md5($yen1)));

                                            $qYonetim= $mysqli-> query("UPDATE yonetim SET SIFRE='$yenisifre'");
                                            $this->uyari("success","ŞİFRE DEĞİŞTİRİLDİ","kontrol.php");;

                                        }

                                    }

                                }

                                else {
                                    
                                    echo '
                                
                                        <form action="" method="post">
                                            <div class="col-md-12 table-light border-bottom"><h4>ŞİFRE DEĞİŞTİR</h4></div>
                                            <div class="col-md-12 table-light"><input type="text" name="eskisif" class="form-control mt-3" require placeholder="eski şifre"/></div>
                                            <div class="col-md-12 table-light"><input type="text" name="yen1" class="form-control mt-3" require placeholder="Yeni şifre"/></div>
                                            <div class="col-md-12 table-light"><input type="text" name="yen2" class="form-control mt-3" require placeholder="Yeni şifre Tekrar"/></div>
                                            <div class="col-md-12 table-light"><input name="buton" type="submit" value="DEĞİŞTİR" class="btn btn-success mt-3 mb-3"/></div>
                                        </form>
                                        ';
                                }
                                        echo '</div>';

    }

    //RAPOR İŞLEMLERİ

    function rapor($mysqli){
        
        $resetRap= $mysqli-> query("TRUNCATE TABLE gecicimasa");
        $resetUrun= $mysqli-> query("TRUNCATE TABLE geciciurun");
        

        $veri1=$mysqli-> query("SELECT * FROM rapor WHERE YEARWEEK(TARIH) = YEARWEEK(CURRENT_DATE)");
        $veri2=$mysqli-> query("SELECT * FROM rapor WHERE YEARWEEK(TARIH) = YEARWEEK(CURRENT_DATE)");

        echo '
        <table class="table text-center table-light table-bordered mx-auto mt-4 table-striped col-md-8">
                <thead>
                <tr>
                    <th>Bugün</th>
                    <th>Dün</th>
                    <th>Bu Hafta</th>
                    <th>Bu Ay</th>
                    <th>Tüm Zamanlar</th>
                    <th colspan="2">İnput</th>
                    <th>Buton</th>
                </tr>
                </thead>
                <tbody>
                    <tr>
                        <th colspan="4">    
                                <table class="table text-center table-bordered col-md-12 table-striped">
                                <thead>
                                    <tr>
                                        <th colspan="4" class="table-dark">Masa Adet ve Hasılat</th>
                                    </tr>
                                </thead>
                                <thead>
                                <tr class="table-danger">
                                    <th colspan="2">Ad</th>
                                    <th colspan="1">Adet</th>
                                    <th colspan="1">Hasılat</th>
                                </tr>

                    </tr>
                    </thead> <tbody>';
                    

                            $kilit=$mysqli->query("SELECT * FROM gecicimasa");
                            
                            if (mysqli_num_rows($kilit)==0) {
                                
                                while ($gel=mysqli_fetch_assoc($veri1)) 
                                {
                                    ///// masa adını çekiyoruz
                                    $id=$gel["MASAID"];
                                    $masaveri=$mysqli->query("SELECT * FROM masalar WHERE ID=$id");
                                    $arrMasaVeri= mysqli_fetch_assoc($masaveri);
                                    $masaad=$arrMasaVeri["MAD"];
                                    ///// masa idsini çekiyoruz
                                    $raporbak=$mysqli->query("SELECT * FROM gecicimasa WHERE MASAID=$id");
                                    if(mysqli_num_rows($raporbak)) 
                                    {
                                    /// ekleme
                                        $has=$gel["ADET"]*$gel["UFIYAT"];
                                        $adet=$gel["ADET"];
                                        $qGeciciM= $mysqli-> query("INSERT INTO gecicimasa (MASAID,MAD,HASILAT,ADET) VALUES ($id,'$masaad',$has,$adet)"); 
                                    }
                                    else {
                                         /// güncelleme
                                        $raporson=mysqli_fetch_assoc($raporbak);
                                        $gelenadet=$raporson["ADET"];
                                        $gelenhas=$raporson["HASILAT"];
                                        $sonhasilat=$gelenhas +($gel["ADET"]* $gel["UFIYAT"]);
                                        $sonadet=$gelenadet+$gel["ADET"];
                                        $updateGeciciMasa= $mysqli-> query("UPDATE gecicimasa SET HASILAT=$sonhasilat, ADET=$sonadet where MASAID=$id");
                                    }
                                }

                            }
                               

                            $son=$mysqli-> query("SELECT * FROM gecicimasa ORDER BY HASILAT DESC;");
                            $toplamadet=0;
                            $toplamhasilat=0;
                            
                            while($listele=mysqli_fetch_assoc($son)) {
                               
                                echo '<tr>
                                <td colspan="2">'.$listele["masaad"].'</td>
                                <td colspan="1">'.$listele["adet"].'</td>
                                <td colspan="1">'.number_format($listele["hasilat"],2,'.','.').'</td>
                                </tr>';
                                $toplamadet+=$listele["adet"];
                                $toplamhasilat+=$listele["hasilat"];
                            }


                            echo '<tr class="table-danger">
                                <td colspan="2">TOPLAM</td>
                                <td colspan="1">'.$toplamadet.'</td>
                                <td colspan="1">'.number_format($toplamhasilat,2,'.','.').'</td>
                            </tr>
                        </tbody>
                        </table>
                    </th>
                    <th colspan="4">
                        <table class="table text-center table-bordered col-md-12 table-striped">
                            <thead>
                                <tr>
                                    <th colspan="4" class="table-dark">Ürün Adet ve Hasılat</th>
                                </tr>
                            </thead>
                            <thead>
                            <tr class="table-danger">
                                <th colspan="2">Ad</th>
                                <th colspan="1">Adet</th>
                                <th colspan="1">Hasılat</th>
                            </tr>
                            </thead> <tbody>';

                            $kilit2=$mysqli-> query("SELECT * FROM geciciurun");

                            if (mysqli_num_rows($kilit2)==0) {

                                 while ($gel2=mysqli_fetch_assoc($veri2)) {

                                    $id=$gel2["URUNID"];
                                    $urunad=$gel2["UAD"];

                                    $raporbak2=$mysqli-> query("SELECT * FROM geciciurun WHERE URUNID=$id");
                                    if($raporbak2->num_rows==0) {
                                        /// ekleme
                                        $has2=$gel2["ADET"]*$gel2["UFIYAT"];
                                        $adet2=$gel2["ADET"];
                                        $ekleGeciciUrun= $mysqli-> query("INSERT INTO geciciurun (URUNID,UAD,HASILAT,ADET) VALUES ($id,'$urunad',$has2,$adet2)");
                                    }
                                    else {
                                        /// güncelleme
                                        $raporson2=mysqli_fetch_assoc($raporbak2);
                                        $gelenadet2=$raporson2["ADET"];
                                        $gelenhas2=$raporson2["HASILAT"];
                                        $sonhasilat2=$gelenhas2 +($gel2["ADET"]* $gel2["UFIYAT"]);
                                        $sonadet2=$gelenadet2+$gel2["ADET"];
                                        $updateGeciciUrun= $mysqli-> query("UPDATE geciciurun SET HASILAT=$sonhasilat2, ADET=$sonadet2 WHERE URUNID=$id");

                                    }
                                    
                                 }

                            }


                            $son2=$mysqli-> query("SELECT * FROM geciciurun ORDER BY HASILAT DESC;");
                            $toplamadet2=0;
                            $toplamhasilat2=0;
                            
                            while($listele2=mysqli_fetch_assoc($son2)) {

                                echo '<tr>
                                <td colspan="2">'.$listele2["UAD"].'</td>
                                <td colspan="1">'.$listele2["ADET"].'</td>
                                <td colspan="1">'.number_format($listele2["HASILAT"],2,'.','.').'</td>
                                </tr>';

                                $toplamadet2+=$listele2["ADET"];
                                $toplamhasilat2+=$listele2["HASILAT"];
                            }

                            echo '
                        </tbody>
                        </table>
                    </th>
                </tr>
                </tbody>
            </table>';


    }



	//giriş kontrolleri
	public function girisKontrol($mysqli, $kulad, $sifre) {

		$cozulmusSıfre= md5(sha1(md5($sifre)));

		$qAdmin= $mysqli-> query("SELECT * FROM yonetim WHERE KADI= '$kulad' AND SIFRE= '$cozulmusSıfre'");

		if(mysqli_num_rows($qAdmin)==0) {
			
			$this->uyari("danger", "Bilgiler hatalı", "index.php");
		}
		else {
	
			$this->uyari("success", "Giriş yapılıyor..", "kontrol.php");

			//cookie oluşturma
			$cozulmusKulad= md5(sha1(md5($kulad)));
			setcookie("admin", $cozulmusKulad, time() + 60*60*24);
		}

	}
	//cookie kontrolleri
	public function cookieKontrol($mysqli, $durum= false) {

		if(isset($_COOKIE["admin"])) {
			
			$deger=$_COOKIE["admin"];

			$qCookie= $mysqli-> query("SELECT * FROM yonetim");
			$re= mysqli_fetch_assoc($qCookie);
			$sonhal=md5(sha1(md5($re["KADI"])));

			if($sonhal!=$_COOKIE["admin"]) {
				setcookie("kul","$deger",time()-10);// gelen değerde sıkıntı varsa cooki öldürüyor
                header("location:index.php");

			}
			else {
				if($durum==true){
					  header("location:kontrol.php");
				}

			}
		}
		else {
			 if($durum==false) {
			 	header("Location:index.php");
			 }

		}
	}
	

}

?>



		