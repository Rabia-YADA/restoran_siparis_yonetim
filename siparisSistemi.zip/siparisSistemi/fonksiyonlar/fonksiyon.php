<?php

$servername = "localhost";
$database = "siparis";
$username = "root";
$password = "root";
// Create connection
$db = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$db) {
    die("Bağlantı Hatası: " . 
mysqli_connect_error());
}
$db->set_charset("utf8");

class sistem {
	

	public function masaCek($mysqli) {

		if ($masalar = $mysqli -> query("SELECT * FROM masalar")) {

			$bos= 0;
			$dolu= 0;
		
			while ( $row= mysqli_fetch_assoc($masalar) ):
				

				$siparisler= $mysqli -> query("SELECT * FROM anlikSiparis WHERE MASAID= ".$row["ID"]." "); //siparişi aktif olan masayı bulmak için 
				$num_rows = mysqli_num_rows($siparisler);
				$num_rows==0 ? $renk="danger" : $renk="success";
				$num_rows==0 ? $bos++ : $dolu++;


				echo '<div class="col-md-2 mx-auto p-2 text-center text-center text-white" id="mas" >
					  <a href="masadetay.php?masaid='.$row["ID"].'"  ><div class="bg-'.$renk.' mx-auto p-2 text-center text-white" id="masa"> '.$row["MAD"].' </div><a/>

					  </div>'; 
	  		endwhile;

	  		$qDoluluk= $mysqli-> query("UPDATE doluluk SET BOS=$bos, DOLU=$dolu WHERE ID=1");
		
		}


	}

	//doluluk oranı
	public function restoranDoluluk($mysqli) {

		$qDoluBilgisi= $mysqli-> query("SELECT * FROM doluluk");
		$arrayDoluluk= mysqli_fetch_assoc($qDoluBilgisi);

		$toplamMasa= $arrayDoluluk["BOS"] + $arrayDoluluk["DOLU"];
		$oran= ($arrayDoluluk["DOLU"]/$toplamMasa)*100; 
		echo $oran= substr($oran, 0, 5). " %";
	}


//MASA TOPLAM SAYI
	public function masaToplam($mysqli) {

		if ($result = $mysqli -> query("SELECT * FROM masalar")) {
		
			echo mysqli_num_rows($result);
		}

	}

	//Sipariş TOPLAM SAYI
	public function siparisToplam($mysqli) {

		if ($result = $mysqli -> query("SELECT * FROM anlikSiparis")) {
		
			echo mysqli_num_rows($result);
		}

	}

	//---MASA DETAY FONKSİYON

	public function masaGetir($mysqli, $mId){

		$masaBilgi = $mysqli -> query("SELECT * FROM masalar WHERE ID= $mId");

		if ($mysqli->errno > 0) {
		    die("<b>Sorgu Hatası:</b> " . $baglanti->error);
		}
		return $masaBilgi;
	
	}


//URUN KATEGORİ FONKSİYON

	public function urunKategori($mysqli){
		$katBilgi = $mysqli-> query("SELECT * FROM kategori");

		if ($mysqli->errno > 0) {
		    die("<b>Sorgu Hatası:</b> " . $baglanti->error);
		}

		while ( $row= mysqli_fetch_assoc($katBilgi) ):
			echo '<a class="btn btn-dark mt-2 text-white" sectionId="'.$row["ID"].'">'.$row["KAD"].'</a><br><br>';
		endwhile;

	}



}




?>



		